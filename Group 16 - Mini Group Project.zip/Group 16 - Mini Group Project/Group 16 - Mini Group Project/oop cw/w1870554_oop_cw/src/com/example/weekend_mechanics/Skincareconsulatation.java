package com.example.weekend_mechanics;
import java.io.FileNotFoundException;


/*------------------Create an interface with methods that in Westminster Skin care consultation-----------------------*/


public interface Skincareconsulatation {
    void addDoctor(Doctor doctor );
    void deleteDoctor(String remove);
    void displaytable();
    void savedetails();
    void recoverdoctors() throws FileNotFoundException;

}

