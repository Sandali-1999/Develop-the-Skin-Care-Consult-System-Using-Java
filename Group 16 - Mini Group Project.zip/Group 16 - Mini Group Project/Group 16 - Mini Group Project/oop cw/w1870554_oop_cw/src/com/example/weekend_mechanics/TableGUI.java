package com.example.weekend_mechanics;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import static com.example.weekend_mechanics.WestministerSkinCareConsultataion.doctornames;
import static com.example.weekend_mechanics.WestministerSkinCareConsultataion.tempdoctornames;

import java.awt.*;
import java.util.Collections;
import java.util.Comparator;
public class TableGUI extends JFrame{

    /*------------------------------------------variables----------------------------------------------------------*/
    private JTable table;
    private JScrollPane scrollPane;


    /*------------------------------create table gui methode to create table---------------------------------------*/

    public TableGUI() {
        setTitle("List of Doctors.....");
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Doctor Id");
        tableModel.addColumn("First Name");
        tableModel.addColumn("Sure name");
        tableModel.addColumn("specialisation");
        tableModel.addColumn("Mobile Number");
        tableModel.addColumn("DOB");

    /*-----------------------------add doctornames array details into the table----------------------------------- */


        for (Doctor doctor : doctornames) {
            tableModel.insertRow(0, new Object[]{doctor.getLisshion(), doctor.getName(), doctor.getSname(),
                    doctor.getSpecili(), doctor.getMobileNum(), doctor.getDob()});

        }
        table = new JTable(tableModel);
        scrollPane = new JScrollPane(table);
        table.setAutoCreateRowSorter(true); /* sorting of the rows on a particular column*/
        table.getTableHeader().setBackground(Color.GRAY);
        add(scrollPane, BorderLayout.CENTER);
        setSize(1800, 800);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}


