package com.example.weekend_mechanics;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class WestministerSkinCareConsultataion implements Skincareconsulatation,Serializable {
    static ArrayList<Doctor> doctornames = new ArrayList<>();/*created a class call doctornames to add all data*/
    static ArrayList<String> tempdoctornames = new ArrayList<>();
    private File table = new File("doctorfile.txt");

    
    /*----------------------------------------- Count number of doctors-----------------------------------------------*/
    
    
    static int maximum_no_of_doctors = 10;

    
    /*---------------------------------------------add doctor method--------------------------------------------------*/
    
    @Override
    public void addDoctor(Doctor doctor) {
        if (maximum_no_of_doctors == doctornames.size()) {
            System.out.println("You reach the maximum number of doctors");
        } else {
            doctornames.add(doctor);
            maximum_no_of_doctors = -1;
        }
    }

    
    /*-----------------------------------------delete doctor method---------------------------------------------------*/

    @Override
    public void deleteDoctor(String remove) {
        if (doctornames.size() == 0) {
            System.out.println("There are no more doctors");
        } else {
            for (int i = 0; i < doctornames.size(); i++) {
                if (doctornames.get(i).getLisshion().equals(remove)) {
                    System.out.println("*Deleted*");
                    doctornames.remove(i);

                    maximum_no_of_doctors = +1;
                    break;
                }
            }
        }
    }

    
    /*------------------------------------------display table method--------------------------------------------------*/

    
    @Override
    public void displaytable() {
        String Table = "| %-14.8s       | %-14.8s   | %-14.8s   | %-14.8s       | %-14.8s      | %-14.8s      | %n";
        System.out.format("_________________________________________________________________________________________________________________________________%n");
        System.out.format("|Doctor Licence number |Doctor First name |Doctor Sure name  |Doctor Specialization |Doctor Date of birth |Doctor Mobile number |%n");
        System.out.format("|______________________|__________________|__________________|______________________|_____________________|_____________________|%n");
        Collections.sort(doctornames, Comparator.comparing(person::getSname));
        for (Doctor doctor:doctornames) {
            System.out.format(Table,doctor.getLisshion(),doctor.getName(), doctor.getSname(),doctor.getSpecili(),doctor.getDob(),doctor.getMobileNum());
        }
    }

    
    /*----------------------------------------save data method--------------------------------------------------------*/
    
    @Override
    public void savedetails(){
        try {
            File tableStatFile = new File("doctorfile.txt");
            table.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                ObjectOutputStream detailStore = new ObjectOutputStream(new FileOutputStream(table));
                if (doctornames.size() == 0) {
                    System.out.println("---------No Doctors Been Stored In The System---------");
                } else {
                    detailStore.writeObject(doctornames);
                    System.out.println("---The Details You Added Have Been Stored Successfully---");
                }
                detailStore.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /*---------------------------recover data method-----------------------------------*/


    @Override
    public void recoverdoctors() throws FileNotFoundException {
        try {
            File file = new File("file.txt");
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                ObjectInputStream recoverData = new ObjectInputStream(new FileInputStream(table));
                doctornames = (ArrayList<Doctor>) recoverData.readObject();
                recoverData.close();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                System.out.print("");
            }
        }

    }

}
//References----->https://ashraigosa.medium.com/saving-and-reloading-data-with-file-serialization-in-java-74b79630ec81
//References----->https://www.javatpoint.com/how-to-print-table-in-java-using-formatter#:~:text=Using%20Java%20Formatter%20Class,-Java%20Formatter%20class&text=The%20class%20provides%20the%20format,data%20in%20the%20table%20format.&text=Syntax%3A,args)