package com.example.weekend_mechanics;
public class patient extends person{
    
    
    /*--------------------------------------------creat variables-----------------------------------------------------*/
    
    
    private String number;
    public int count;
    
    
    /*----------------------------------------creat constructor-------------------------------------------------------*/
    
    public patient(String number, String name, String Sname, String dob, String mobileNum) {
        super(name, mobileNum, dob,Sname);
        this.number =number;
    }
    
    
    /*------------------------------------------Creat getter setter methods-------------------------------------------*/
    
    
    public String getNumber() {return number;}
    public void setNumber(String number) {this.number = number;}
    public int getCount() {return count;}
    public void setCount(int count) {this.count = count;}
    
    
    /*--------------------------------to String methode for return String values--------------------------------------*/
 
    
    @Override
    public String toString()
    {
        return  number ;
    }
}
