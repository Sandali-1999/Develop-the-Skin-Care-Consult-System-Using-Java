package com.example.weekend_mechanics;
import javax.crypto.SecretKey;
import javax.swing.*;

import static com.example.weekend_mechanics.Counsultataion.*;
import static com.example.weekend_mechanics.WestministerSkinCareConsultataion.doctornames;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.security.MessageDigest;
public class GUIAddpatient {
    private static final String UNICODE_FORMAT = "UTF-8";


    /*---------------------------------------------Create consultation object-----------------------------------------*/

    static Counsultataion counsultataion = new Counsultataion();


    /*--------------------------------------------------Create variable-----------------------------------------------*/

    String encrypteddetails= null;
    String timeAdded;


    /*----------------------------------------Add label and JTextField into the JPanel------------------------------- */


    GUIAddpatient() {

        JFrame frame = new JFrame("Patient Consultation");
        JPanel panel = new JPanel();
        frame.setSize(1900, 800);
        frame.add(panel);


    /*----------------------------creat jLabels and text Fields to get user inputs------------------------------------*/


        JLabel label5 = new JLabel("Patient id: ");
        label5.setBounds(10, 20, 80, 50);
        panel.add(label5);
        JTextField patataionId = new JTextField(20);
        patataionId.setBounds(100, 200, 165, 25);
        panel.add(patataionId);

        JLabel label1 = new JLabel("First name: ");
        label1.setBounds(10, 20, 80, 25);
        panel.add(label1);
        JTextField fName = new JTextField(50);
        fName.setBounds(100, 200, 165, 25);
        panel.add(fName);

        JLabel label2 = new JLabel("Sure name: ");
        label2.setBounds(10, 20, 80, 25);
        panel.add(label2);
        JTextField sName = new JTextField(50);
        sName.setBounds(100, 200, 165, 25);
        panel.add(sName);

        JLabel label3 = new JLabel("Date of birth: ");
        label3.setBounds(10, 20, 80, 25);
        panel.add(label3);
        JTextField dob = new JTextField(10);
        dob.setBounds(100, 200, 165, 25);
        panel.add(dob);

        JLabel label4 = new JLabel("Mobile number: ");
        label4.setBounds(10, 20, 80, 25);
        panel.add(label4);
        JTextField mob = new JTextField(10);
        mob.setBounds(100, 200, 165, 25);
        panel.add(mob);

        JLabel label6 = new JLabel("Date: ");
        label6.setBounds(10, 20, 80, 25);
        panel.add(label6);
        JTextField date = new JTextField(5);
        date.setBounds(100, 200, 165, 25);
        panel.add(date);

        JLabel label7 = new JLabel("Select Time: ");
        label7.setBounds(10, 20, 80, 25);
        panel.add(label7);
        JLabel time = new JLabel();
        time.setBounds(10, 20, 80, 25);
        panel.add(time);

        ButtonGroup G2;

        JRadioButton jRadioButton9 = new JRadioButton();
        JRadioButton jRadioButton10 = new JRadioButton();
        JRadioButton jRadioButton11 = new JRadioButton();
        JRadioButton jRadioButton12 = new JRadioButton();
        JRadioButton jRadioButton13 = new JRadioButton();
        JRadioButton jRadioButton14 = new JRadioButton();
        JRadioButton jRadioButton15 = new JRadioButton();
        JRadioButton jRadioButton16 = new JRadioButton();

        G2 = new ButtonGroup();

        jRadioButton9.setText("10 A.M-11 A.M");
        jRadioButton10.setText("11 A.M-12 P.M");
        jRadioButton11.setText("12 P.M-13 P.M");
        jRadioButton12.setText("13 P.M-14 P.M");
        jRadioButton13.setText("14 P.M-15 P.M");
        jRadioButton14.setText("15 P.M-16 P.M");
        jRadioButton15.setText("16 P.M-17 P.M");
        jRadioButton16.setText("17 P.M-18 P.M");

        jRadioButton9.setBounds(120, 30, 120, 50);
        jRadioButton10.setBounds(250, 30, 80, 50);
        jRadioButton11.setBounds(120, 30, 120, 50);
        jRadioButton12.setBounds(250, 30, 80, 50);
        jRadioButton13.setBounds(120, 30, 120, 50);
        jRadioButton14.setBounds(250, 30, 80, 50);
        jRadioButton15.setBounds(120, 30, 120, 50);
        jRadioButton16.setBounds(250, 30, 80, 50);

        G2.add(jRadioButton9);
        G2.add(jRadioButton10);
        G2.add(jRadioButton11);
        G2.add(jRadioButton12);
        G2.add(jRadioButton13);
        G2.add(jRadioButton14);
        G2.add(jRadioButton15);
        G2.add(jRadioButton16);

        panel.add(jRadioButton9);
        panel.add(jRadioButton10);
        panel.add(jRadioButton11);
        panel.add(jRadioButton12);
        panel.add(jRadioButton13);
        panel.add(jRadioButton14);
        panel.add(jRadioButton15);
        panel.add(jRadioButton16);

        JLabel label8 = new JLabel("Note: ");
        label8.setBounds(10, 20, 80, 25);
        panel.add(label8);
        JTextArea note = new JTextArea(8,70);
        note.setBounds(100, 200, 165, 25);
        panel.add(note);

        JLabel label10 = new JLabel("Specialization: ");
        label8.setBounds(10, 20, 80, 25);
        panel.add(label10);
        JTextField Specilization = new JTextField(20);
        Specilization.setBounds(100, 200, 165, 25);
        panel.add(Specilization);

        JLabel label11 = new JLabel("Doctor license no: ");
        label8.setBounds(10, 20, 80, 25);
        panel.add(label11);
        JTextField doctor = new JTextField(25);
        doctor.setBounds(100, 200, 165, 25);
        panel.add(doctor);

        JLabel label9 = new JLabel("Cost: ");
        label9.setBounds(10, 20, 80, 25);
        panel.add(label9);
        JTextField cost = new JTextField("Press the 'Submit' button then System will Automatically give the cost...");
        cost.setBounds(100, 200, 165, 25);
        panel.add(cost);


    /*-----------------------Creat three Buttons to submit,browse and encrypt data methods----------------------------*/


        JButton button = new JButton("Submit...");
        button.setBounds(10, 80, 80, 25);
        panel.add(button);

        JButton button1 = new JButton("Browse...");
        button.setBounds(10, 80, 80, 25);
        panel.add(button1);

        JLabel label12 = new JLabel();
        label12.setBounds(10, 10, 670, 250);
        panel.add(label12);
        JButton button3 = new JButton("Encrypt Data...");
        button3.setBounds(10, 80, 80, 25);
        panel.add(button3);


    /*--------------------------------Set layout and Background color-------------------------------------------------*/


        panel.setLayout(new FlowLayout(24,15,2));
        panel.setBackground(new Color(0x87CEEB));


    /*------------------------------------------ encryption button action---------------------------------------------*/

        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                genarateKey();
                note.setText(encrypteddetails);
                label12.setText(encrypteddetails);
            }
        });


    /*--------------------------------------- submit data button action-----------------------------------------------*/


        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = fName.getText();
                try {
                    while (!name.matches(("^[a-zA-Z]+$"))) {
                        fName.setText("");
                        name = fName.getName();
                    }
                }catch (Exception exception){

                }
                String sname = sName.getText();
                try {
                    while (!sname.matches(("^[a-zA-Z]+$"))) {
                        sName.setText("");
                        sname = sName.getName();
                    }
                }catch (Exception exception){

                }
                String daob = dob.getText();
                String mobnum = mob.getText();
                String datee = date.getText();
                String timee = time.getText();
                String notee = note.getText();
                String Speci = Specilization.getText();
                try {
                    while (!Speci.matches(("^[a-zA-Z]+$"))) {
                        Specilization.setText("");
                        Speci = Specilization.getName();
                    }
                }catch (Exception exception){

                }
                String doc = doctor.getText();
                String lissson = patataionId.getText();
                String picture = label12.getText();
                String radioButton = String.valueOf(G2.getButtonCount());
                if(jRadioButton9.isSelected()){
                    timee="10 A.M-11 A.M";
                } else if (jRadioButton10.isSelected()) {
                    timee="11 A.M-12 P.M";
                } else if (jRadioButton11.isSelected()) {
                    timee="12 P.M-13 P.M";
                } else if (jRadioButton12.isSelected()) {
                    timee="13 P.M-14 P.M";
                } else if (jRadioButton13.isSelected()) {
                    timee="14 P.M-15 P.M";
                } else if (jRadioButton14.isSelected()) {
                    timee="15 P.M-16 P.M";
                } else if (jRadioButton15.isSelected()) {
                    timee="16 P.M-17 P.M";
                } else if (jRadioButton16.isSelected()) {
                    timee="17 P.M-18 P.M";
                }

                patient p1 = new patient(lissson, name, sname, daob, mobnum);
                counsultataion.addpatataion(p1);
                int count = p1.getCount();
                p1.setCount(count + 1);


    /*------------------------------------------ check the partition is duplicate ------------------------------------*/


                int same = 0;
                if (tempList.size() >= 1) {
                    for (com.example.weekend_mechanics.patient ignored : patient) {

                        if (tempList.contains(ignored.getNumber())) {
                            same = 2;
                        } else {
                            same = 1;
                        }
                    }
                    tempList.add(String.valueOf(lissson));
                } else {
                    same = 1;
                    tempList.add(String.valueOf(lissson));
                }
                String pcost = " ";
                if (same == 1) {
                    cost.setText("15");
                    pcost = cost.getText();

                }
                else if (same == 2) {
                    cost.setText("25");
                    pcost = cost.getText();
                }
                Counsultataion c1 = new Counsultataion(lissson, name, sname, daob, mobnum, datee, timee, notee, pcost, doc, Speci,picture,radioButton);
                counsultataion.addConsultataion(c1);


    /*------------------------------------------ check the doctor is available----------------------------------------*/


                int same1 = 0;
                if (tempList1.size() >= 1) {
                    for (com.example.weekend_mechanics.Counsultataion ignored : consuitataion1) {
                        if (tempList1.contains(ignored.getDate())  && tempList1.contains(ignored.getDoc()) && tempList1.contains(ignored.getRadioButton())) {
                            same1 = 2;
                        } else {
                            same1 = 1;
                        }
                    }
                    tempList1.add(doc);
                    tempList1.add(datee);
                    tempList1.add(Speci);
                    tempListOfencription.add(notee);
                    tempListOfencription.add(String.valueOf(label2));

                } else {

                    same1 = 1;
                    tempList1.add(doc);
                    tempList1.add(datee);
                    tempList1.add(radioButton);
                    tempList1.add(Speci);
                    tempListOfencription.add(notee);
                    tempListOfencription.add(String.valueOf(label2));
                }

                if (same1 == 1) {

                }

                else if (same1 == 2) {
                    for (com.example.weekend_mechanics.Counsultataion ignored : consuitataion1) {
                        for (int i = 0; i < doctornames.size(); i++) {
                            if (doctornames.get(i).getSpecili().equals(ignored.getSpe())) {
                                if (!doctornames.get(i).getLisshion().equals(ignored.getDoc())) {
                                    if (tempList1.contains(ignored.getDate())  && tempList1.contains((ignored.getRadioButton()))) {
                                        doctor.setText(doctornames.get(i).getLisshion());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });


    /*------------------------------------------- insert picture button-----------------------------------------------*/


        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser file = new JFileChooser();
                file.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filer = new FileNameExtensionFilter(" *.Image","jpg","gif"+"png");
                file.addChoosableFileFilter(filer);
                int result = file.showSaveDialog(null);
                if(result ==JFileChooser.APPROVE_OPTION){
                    File selectedFile = file.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    label12.setIcon(ResizeImage(path));
                } else if (result==JFileChooser.CANCEL_OPTION ) {
                    System.out.println("No file found");
                }
            }
        });
        frame.setVisible(true);
    }


    /*-------------------------------------------- add picture -------------------------------------------------------*/

    public ImageIcon ResizeImage(String ImagePath) {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(670,250,Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }


    /*------------------------------------------ encryption data------------------------------------------------------*/


    public  SecretKey genarateKey(){
        String details = String.valueOf(tempListOfencription);

        try
        {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(details.getBytes());

            byte[] bytes = m.digest();

            StringBuilder s = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            encrypteddetails = s.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        return null;
    }
}

//Reference----->https://1bestcsharp.blogspot.com/2015/04/java-how-to-browse-image-file-and-And-Display-It-Using-JFileChooser-In-Java.html