package com.example.weekend_mechanics;
import java.awt.*;
import java.io.IOException;


public class main {
    public static void main(String args[]) throws IOException, FontFormatException {

        WestministerSkinCareConsultataion fobj = new WestministerSkinCareConsultataion();/*create westminster skin care consultation object */
        fobj.recoverdoctors();/*recover data*/
        Concole c1 = new Concole();
        c1.menulsit(); /*Calling console method to show option*/
        new GUI(); /*calling main interface*/
    }
}