package com.example.weekend_mechanics;
import static com.example.weekend_mechanics.Counsultataion.consuitataion1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
public class GUIConsultataionDetails {
    GUIConsultataionDetails(){
        JFrame frame = new JFrame("Patient Consultation Details....");
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);

        /*--------------------------------------Adding Columns----------------------------------------------------*/


        tableModel.addColumn("Patient ID");
        tableModel.addColumn("Patient First name");
        tableModel.addColumn("Patient Surname");
        tableModel.addColumn("Patient Mobile number");
        tableModel.addColumn("Consult date");
        tableModel.addColumn("Time");
        tableModel.addColumn("Note");
        tableModel.addColumn("Cost");
        tableModel.addColumn("Doctor Specialization");
        tableModel.addColumn("Doctor ID");
        tableModel.addColumn("picture");


        /*--------------------------------Add consultation1 array details into the table-------------------------*/


        for(Counsultataion counsultataion : consuitataion1){
            tableModel.insertRow(0, new Object[]{counsultataion.getLission(),counsultataion.getName(),counsultataion.getSname(),
                    counsultataion.getMobileNum(), counsultataion.getDate(),counsultataion.getTime(), counsultataion.getNote(),
                    counsultataion.getCost(), counsultataion.getSpe(), counsultataion.getDoc(),counsultataion.getPictire()});
        }

        final TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
        table.setRowSorter(sorter);
        JScrollPane pane = new JScrollPane(table);
        frame.add(pane, BorderLayout.CENTER);

        JPanel panel = new JPanel(new BorderLayout());
        frame.add(panel, BorderLayout.NORTH);
        table.getTableHeader().setBackground(Color.GRAY);
        Font  font  = new Font(Font.DIALOG_INPUT,  Font.BOLD, 20);
        Border whiteline = BorderFactory.createLineBorder(Color.GRAY);
        Border compound;



    /*------------------------------------------Add button to search--------------------------------------------------*/






        frame.setSize(1200, 800);
        frame.setVisible(true);
    }
}
