package com.example.weekend_mechanics;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class GUI extends JFrame {

    public JFrame menu() {

        JFrame frame = new JFrame("Westminster Skin Care Consultation");
        ImageIcon backgroundImg = new ImageIcon("oop cw/w1870554_oop_cw/src/gg.png");
        JLabel blabel = new JLabel(backgroundImg);

        JLabel heading1 = new JLabel("WELCOME TO");
        JLabel heading = new JLabel("WESTMINSTER SKIN CARE MENU");


    /*-----------------------------------Creat three main buttons in GUI menu---------------------------------------------*/


        JButton b1 = new JButton("Doctors");
        JButton b2 = new JButton("Consultation");
        JButton b3 = new JButton("Patient Details");

        heading.setForeground(new Color(0x000000));
        heading.setFont(heading.getFont().deriveFont(20f));
        heading1.setForeground(new Color(0x800000));
        heading1.setFont(heading.getFont().deriveFont(40f));


        Border compound;
        b1.setBounds(550, 320, 200, 60);
        b1.setFocusable(false);
        b1.setFont(new Font("Comic Sans", Font.BOLD, 25));
        b1.setBorder(new LineBorder(Color.black, 5, true));



        b2.setBounds(650, 420, 200, 60);
        b2.setFocusable(false);
        b2.setFont(new Font("Comic Sans", Font.BOLD, 25));
        b2.setBorder(new LineBorder(Color.black, 5, true));

        b3.setBounds(750, 520, 200, 60);
        b3.setFocusable(false);
        b3.setFont(new Font("Comic Sans", Font.BOLD, 25));
        b3.setBorder(new LineBorder(Color.black, 5, true));

        heading.setBounds(300, 200, 750, 75);
        heading.setFont(new Font("MONOSPACED", Font.BOLD, 40));
        heading1.setBounds(450, 150, 750, 75);
        heading1.setFont(new Font("MONOSPACED", Font.BOLD, 50));

        frame.add(b1);
        frame.add(b2);
        frame.add(b3);
        frame.add(heading);
        frame.add(heading1);
        frame.setSize(1200, 675);
        blabel.setBounds(500, 500, 2000, 1200);
        frame.add(blabel);


        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    /*----------------------------------show table of docters button method-------------------------------------------*/


        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TableGUI();
                frame.setVisible(true);
            }
        });


    /*-------------------------------------------------add Patient----------------------------------------------------*/


        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIAddpatient();
                frame.setVisible(false);
            }
        });


    /*------------------------------------show table of consultation details------------------------------------------*/


        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIConsultataionDetails();
                frame.setVisible(false);
            }
        });
        return frame;
    }
}