package com.example.weekend_mechanics;
import java.awt.*;
import java.util.Scanner;

public class Concole {


    /*---------------------------------------------------create object----------------------------------------------- */

    static WestministerSkinCareConsultataion westministerSkinCareConsultataion=new WestministerSkinCareConsultataion();
    static GUI gui = new GUI();


    /*-------------------------------------------create menu--------------------------------------------------------- */

    public static void menu() {
        System.out.println("..........Main menu...............");
        System.out.println("_____________________________________");
        System.out.println("Press 1 :Add a Doctor");
        System.out.println("Press 2 :Delete doctor");
        System.out.println("Press 3 :Display list of doctors");
        System.out.println("Press 4 :Save files");
        System.out.println("Press 5 :Open GUI menu");
        System.out.println("Press 6 :Exist");
        System.out.println("------------------------------------");
        System.out.print("Enter the number (between 1-6) :- ");
    }
    Scanner input = new Scanner(System.in);


    /*-------------------------------------------create menu List---------------------------------------------------- */

    public void menulsit() throws FontFormatException {
        menu();
        String instruct;
        instruct = input.next();
        while (instruct!="6") {
            if (instruct.equals("1")) {
                doctorinput();
                menulsit();
            } else if (instruct.equals("2")) {
                deleteinput();
                menulsit();
            }  else if (instruct.equals("3")) {
                westministerSkinCareConsultataion.displaytable();
                menulsit();
            }  else if (instruct.equals("4")) {
                westministerSkinCareConsultataion.savedetails();
                menulsit();
            }  else if (instruct.equals("6")) {
                exit();
            }  else if (instruct.equals("5")) {
                System.out.println("GUI is opening........");
                gui.menu();
                menulsit();
            }
            else {
                System.out.println("Wrong Input");
                menulsit();
            }
        }
    }



    /*------------------------------------create doctor input methode------------------------------------------------ */


    private void doctorinput() {
        System.out.print("Enter Doctor license number:");
            String lisshoin = input.next();
            while (true) {
            String same = "none";
            for (Doctor doctor : WestministerSkinCareConsultataion.doctornames) {
                if (doctor.getLisshion().equals(lisshoin)) {
                    same = "repeated_num";
                    break;
                }
            }
            if (same == "repeated_num") {
                System.out.println("Doctor is Already Added.Try a different license number....");
                System.out.print("Reenter license:");
                lisshoin = input.next();
            }
            else {
                break;
            }
        }

        String new_name;
        System.out.print("Enter Doctor's name:");
        new_name = input.next();
        try{
            while (!new_name.matches("^[a-zA-Z]+$")){
                System.out.println("Wrong Input.... \nSorry only use String value ");
                System.out.print("Enter Doctor's name:");
                new_name = input.next();
            }
        }catch(Exception e){
            System.out.println(e.toString());
        }
        while (true) {
            String same = "none";
            for (Doctor doctor : WestministerSkinCareConsultataion.doctornames) {
                if (doctor.getName().equals(new_name)) {
                    same = "repeated_name";
                    break;
                }
            }
            if (same == "repeated_name") {
                System.out.println("Doctor is Already Added.Try a different name....");
                System.out.print("Reenter the name:");
                new_name = input.next();
            }
            else {
                break;
            }
        }
        System.out.print("Enter Doctor's Sure name:");
        String Sname = input.next();
        try{
            while (!Sname.matches(("^[a-zA-Z]+$"))){
                System.out.println("Wrong Input.... \nSorry only use String value ");
                System.out.print("Enter Doctor's Sure name:");
                Sname = input.next();

            }
        }catch(Exception e){
            System.out.println(e.toString());
        }

        while (true) {
            String same = "none";
            for (Doctor doctor : WestministerSkinCareConsultataion.doctornames) {
                if (doctor.getSname().equals(Sname)) {
                    same = "repeated_name";
                    break;
                }
            }
            if (same == "repeated_name") {
                System.out.println("Doctor is Already Added.Try a different name....");
                System.out.print("Reenter sure name:");
                Sname = input.next();
            }
            else {
                break;
            }
        }
        System.out.print("Enter Doctor date of birth:");
        String doctor_dob = input.next();
        System.out.print("Enter Doctor Specialization:");
        String speci = input.next();
        System.out.print("Enter Doctor's mobile number:");
        String mobilrnum = input.next();
        try {
                while (!speci.matches(("^[a-zA-Z]+$"))) {
                        System.out.println("Wrong Input.... \nSorry only use String value ");
                        System.out.print("Enter Doctor Specialization:");
                        speci = input.next();
                }

            } catch (Exception e) {
                System.out.println(e.toString());
            }


        Doctor d1 = new Doctor(new_name, mobilrnum, doctor_dob, lisshoin, Sname, speci);
        westministerSkinCareConsultataion.addDoctor(d1);


    }


    /*-----------------------------------create doctor delete input methode------------------------------------------ */


    private void deleteinput(){
        String delete_num;
        System.out.print("Enter Doctor's number:");
        delete_num = input.next();
        while (true) {
            String sameLission = "none";
            for (Doctor formula1driver : WestministerSkinCareConsultataion.doctornames) {
                if (formula1driver.getLisshion().equals(delete_num)) {
                    sameLission = "repeated_num";
                    break;
                }
            }
            if (!sameLission.equals("repeated_num") ) {
                System.out.println("There is no number similar to this..");
                System.out.print("Reenter number:");
                delete_num=input.next();
            }
            else {
                break;
            }
        }
        westministerSkinCareConsultataion.deleteDoctor(delete_num);
    }


    /*----------------------------------------------exit method------------------------------------------------------ */


    public void exit(){
        System.out.println("Program Exited...");
        System.exit(-1);
    }
}

//Reference---->https://www.w3schools.com/java/java_files_create.asp