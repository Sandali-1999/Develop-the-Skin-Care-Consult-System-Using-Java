package com.example.weekend_mechanics;
import java.io.Serializable;
public abstract class person implements Serializable {


    /*-------------------------------------Create private variables-----------------------------------------------*/


    private String name;
    private String Sname;
    private String mobileNum;
    private String dob;

    /*---------------------------------------Constructor-------------------------------------------------------*/
    public person(String name, String mobileNum, String dob,String Sname) {
        this.name = name;
        this.mobileNum = mobileNum;
        this.dob = dob;
        this.Sname=Sname;
    }


    /*--------------------------------------Getter Setter for above variables-----------------------------------*/


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /*Getter Setter for mobile number*/

    public String getMobileNum() {
        return mobileNum;
    }

    public void setMobileNum(String mobileNum) {
        this.mobileNum = mobileNum;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String sname) {
        Sname = sname;
    }


    /*-------------------------------------------------To String-------------------------------------------------*/

    @Override
    public String toString() {
        return
                name + '\'' +
                        Sname + '\'' +
                        mobileNum + '\'' +
                        dob + '\''
                ;
    }
}

