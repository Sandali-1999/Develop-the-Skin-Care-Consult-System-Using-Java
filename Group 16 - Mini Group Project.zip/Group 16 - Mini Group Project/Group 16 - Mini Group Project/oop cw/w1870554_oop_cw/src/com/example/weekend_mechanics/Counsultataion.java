package com.example.weekend_mechanics;
import javax.swing.*;
import java.util.ArrayList;
public class Counsultataion {



    /*----------------------------------------------create array list-------------------------------------------------*/


    static ArrayList<patient> patient = new ArrayList<patient>();
    static ArrayList<Counsultataion> consuitataion1 = new ArrayList<Counsultataion>();
    static  ArrayList <String> tempList = new ArrayList<String >();
    static  ArrayList <String> tempList1 = new ArrayList<String >();
    static  ArrayList <String> tempListOfencription = new ArrayList<String >();



    /*--------------------------------------------------variables-----------------------------------------------------*/


    String date;
    String time;
    String cost;
    String note;
    Doctor doctor;
    String doc;
    String spe;
    String lission;
    String name;
    String Sname;
    String mobileNum;
    String dob;
    String pictire;
    String radioButton;


    /*-----------------------------------create constructor for other method------------------------------------------*/


    public Counsultataion() {
    }

    /*-------------------------------create constructor for add consultation method-----------------------------------*/


    public Counsultataion(String lission, String name, String Sname, String mobileNum, String dob, String date, String time, String note, String cost, String doc, String spe, String pictire,String radioButton) {
        this.lission =lission;
        this.name = name;
        this.Sname = Sname;
        this.dob=dob;
        this.mobileNum=mobileNum;
        this.date = date;
        this.time = String.valueOf(time);
        this.cost = cost;
        this.note = note;
        this.doc = doc;
        this.spe=spe;
        this.pictire =pictire;
        this.radioButton=radioButton;
    }




    /*--------------------------------------------getter and setter method--------------------------------------------*/



    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getSpe() {
        return spe;
    }

    public void setSpe(String spe) {
        this.spe = spe;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }


    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getLission() {
        return lission;
    }

    public void setLission(String lission) {
        this.lission = lission;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String sname) {
        Sname = sname;
    }

    public String getMobileNum() {
        return mobileNum;
    }

    public void setMobileNum(String mobileNum) {
        this.mobileNum = mobileNum;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPictire() {
        return pictire;
    }

    public void setPictire(String pictire) {
        this.pictire = pictire;
    }

    public String getRadioButton() {return radioButton;}

    public void setRadioButton(String radioButton) {this.radioButton = radioButton;}


    /*------------------------------create methode to add element into the array list---------------------------------*/


    public void addpatataion(patient patatio) {
        patient.add(patatio);
    }
    public void addConsultataion(Counsultataion counsultataion) {
        consuitataion1.add(counsultataion);
    }


    /*-----------------------------------------------------to string--------------------------------------------------*/



    @Override
    public String toString() {
        return
                 date  +
                 time  +
                 cost + note +  doctor + doc +  spe +
                 lission +  name + Sname + mobileNum +
                 dob +  pictire + radioButton ;
    }
}