package com.example.weekend_mechanics;
public class Doctor extends person {


    /*---------------------------------------------create variable------------------------------------------- */

    private String specili;
    private String lisshion;


    /*---------------------------------constructor for add doctor method--------------------------------------*/


    public Doctor(String name, String mobileNum, String dob,String lisshon,String Sname,String speci) {
        super(name, mobileNum, dob,Sname);
        this.lisshion=lisshon;
        this.specili=speci;
    }


    /*------------------------------------getters and setters------------------------------------------------*/


    public String getLisshion() {
        return lisshion;
    }

    public void setLisshion(String lisshion) {
        this.lisshion = lisshion;
    }
    public String getSpecili() {
        return specili;
    }

    public void setSpecili(String specili) {
        this.specili = specili;
    }


    /*------------------------------------to String------------------------------------------------*/

    @Override
    public String toString() {
        return super.toString()+   specili + '\'' +
                lisshion + '\''
                ;
    }
}

