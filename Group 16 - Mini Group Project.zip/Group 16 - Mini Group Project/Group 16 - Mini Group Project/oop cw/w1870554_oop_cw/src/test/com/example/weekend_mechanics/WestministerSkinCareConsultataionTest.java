package test.com.example.weekend_mechanics; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/**
* WestministerSkinCareConsultataion Tester. 
* 
* @author <Authors name> 
* @since <pre>Jan 7, 2023</pre> 
* @version 1.0 
*/ 
public class WestministerSkinCareConsultataionTest {

    @Before
    public void before() throws Exception {
    }

    @After
    public void after() throws Exception {
    }

    /**
     * Method: addDoctor(Doctor doctor)
     */
    @Test
    public void testAddDoctor() throws Exception {
        // TODO: Test goes here...
    }

    /**
     * Method: deleteDoctor(String remove)
     */
    @Test
    public void testDeleteDoctor() throws Exception {
//TODO: Test goes here... 
    }

    /**
     * Method: displaytable()
     */
    @Test
    public void testDisplaytable() throws Exception {
//TODO: Test goes here... 
    }

    /**
     * Method: savedetails()
     */
    @Test
    public void testSavedetails() throws Exception {
//TODO: Test goes here... 
    }

    /**
     * Method: recoverdoctors()
     */
    @Test
    public void testRecoverdoctors() throws Exception {
//TODO: Test goes here... 
    }
}